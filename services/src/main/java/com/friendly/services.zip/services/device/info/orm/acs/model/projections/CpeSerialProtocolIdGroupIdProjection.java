package com.friendly.services.device.info.orm.acs.model.projections;

public interface CpeSerialProtocolIdGroupIdProjection {
    String getSerial();
    Integer getProtocolId();
    Long getGroupId();
}
