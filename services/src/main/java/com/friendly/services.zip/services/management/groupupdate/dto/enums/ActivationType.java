package com.friendly.services.management.groupupdate.dto.enums;

public enum ActivationType {
    UpdateActivate,
    UpdateAdd,
    UpdateImport,
    UpdateStop,
    UpdateDel,
    UpdateEdit,
    ScheduledActivate
}
