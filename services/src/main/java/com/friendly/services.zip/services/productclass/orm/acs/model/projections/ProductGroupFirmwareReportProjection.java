package com.friendly.services.productclass.orm.acs.model.projections;

public interface ProductGroupFirmwareReportProjection extends ProductGroupWithCountProjection {
    String getFirmware();
}