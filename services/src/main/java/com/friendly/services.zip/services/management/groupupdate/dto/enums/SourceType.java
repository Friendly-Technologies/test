package com.friendly.services.management.groupupdate.dto.enums;

public enum SourceType {
    All,
    Group,
    Individual
}