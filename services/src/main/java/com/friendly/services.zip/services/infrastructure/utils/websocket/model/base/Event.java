package com.friendly.services.infrastructure.utils.websocket.model.base;

public interface Event {
}
