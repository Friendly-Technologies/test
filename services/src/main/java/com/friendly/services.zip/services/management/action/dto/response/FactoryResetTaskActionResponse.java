package com.friendly.services.management.action.dto.response;

import lombok.Data;

@Data
public class FactoryResetTaskActionResponse extends AbstractActionResponse {
}
