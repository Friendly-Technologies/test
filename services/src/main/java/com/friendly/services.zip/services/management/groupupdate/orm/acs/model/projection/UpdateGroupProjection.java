package com.friendly.services.management.groupupdate.orm.acs.model.projection;

public interface UpdateGroupProjection {
     Long getUgId();
     Long getUgChildId();
     String getState();
}
