package com.friendly.services.device.parameterstree.orm.acs.model.projections;

public interface ParameterNameIdTypeProjection {
    Long getId();
    String getName();
    String getType();
}