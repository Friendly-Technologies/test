package com.friendly.services.qoemonitoring.orm.qoe.model.enums;

public enum DiagnosticType {
    DownloadDiagnostic,
    UploadDiagnostic
}
