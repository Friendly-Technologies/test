package com.friendly.services.management.groupupdate.dto.enums;

public enum GroupUpdateActivationType {
    Scheduled,
    Immediately
}