package com.friendly.services.productclass.orm.acs.model.projections;

public interface ProductGroupInfoProjection {
    public String getDomainName();
    public String getManufacturerName();
    public String getModel();
}