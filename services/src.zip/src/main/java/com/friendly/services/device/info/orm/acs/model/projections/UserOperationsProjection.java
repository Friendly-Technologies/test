package com.friendly.services.device.info.orm.acs.model.projections;

public interface UserOperationsProjection {
    Long getOperations();
    String getDateOp();
    Long getUserId();
}
