package com.friendly.services.infrastructure.utils.websocket.model.base;

/**
 * Created by alexandr.kaygorodov (12.11.2020)
 * */
public enum EventType {
    Created,
    Deleted,
    Updated
}
