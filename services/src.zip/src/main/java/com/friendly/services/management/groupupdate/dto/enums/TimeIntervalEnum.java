package com.friendly.services.management.groupupdate.dto.enums;

public enum TimeIntervalEnum {
    None,
    Minutely,
    Hourly,
    Daily,
    Weekly,
    Monthly,
    Yearly
}