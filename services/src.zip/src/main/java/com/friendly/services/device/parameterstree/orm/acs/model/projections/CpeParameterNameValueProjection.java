package com.friendly.services.device.parameterstree.orm.acs.model.projections;

public interface CpeParameterNameValueProjection {
    String getName();
    String getValue();
}