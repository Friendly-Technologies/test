package com.friendly.services.management.profiles.entity;

public enum ProfileStatus {
    NOT_ACTIVE,
    ACTIVE,
    ALL
}
