package com.friendly.services.management.profiles.entity.deviceprofile;

import lombok.Getter;

@Getter
public class DeviceProfileBody {
    private Integer id;
}
