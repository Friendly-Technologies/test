package com.friendly.services.device.parameterstree.orm.acs.model.projections;

public interface CpeParameterCpeNameValueProjection {
    Long getCpeId();
    Long getNameId();
    String getValue();
}