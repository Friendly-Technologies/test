package com.friendly.services.device.diagnostics.ws;

public interface DiagnosticToDiagnosticWsHandler {
    String REQUESTED = "Requested";

    void handleDiagnosticToDiagnosticWs();
}