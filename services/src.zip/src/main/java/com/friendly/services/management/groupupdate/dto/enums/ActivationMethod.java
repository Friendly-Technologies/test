package com.friendly.services.management.groupupdate.dto.enums;

public enum ActivationMethod {
    NotActivated,
    ActivatedScheduled,
    ActivatedManual
}

