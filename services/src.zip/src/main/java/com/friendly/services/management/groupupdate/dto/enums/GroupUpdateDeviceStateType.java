package com.friendly.services.management.groupupdate.dto.enums;

public enum GroupUpdateDeviceStateType {
    NOT_SET,
    PENDING,
    COMPLETED,
    FAILED,
    OFFLINE,
    CONDITIONAL,
    SKIPPED
}
