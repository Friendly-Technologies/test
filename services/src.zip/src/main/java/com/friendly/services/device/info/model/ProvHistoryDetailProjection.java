package com.friendly.services.device.info.model;

public interface ProvHistoryDetailProjection {
    Integer getNameId();

    String getValue();
}
